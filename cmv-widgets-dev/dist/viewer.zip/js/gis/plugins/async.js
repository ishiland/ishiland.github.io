/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define(function(){var d="_asyncApiLoaderCallback";return{load:function(o,n,i){d&&(window.dojoConfig[d]=function(){delete window.dojoConfig[d],d=null,i()},require([o+"&callback=dojoConfig."+d]))}}});
//# sourceMappingURL=async.js.map