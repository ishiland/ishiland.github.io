/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({title:"Mapas base"});
//# sourceMappingURL=resource.js.map