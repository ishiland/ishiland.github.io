/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{address:"Endereço",neighborhood:"Bairro",city:"Cidade",subregion:"Subregião",region:"Região",postalCode:"Código Postal (CEP)",countryCode:"Código do País",locatorName:"Nome do Localizador",getAddressHere:"Obtenha o Endereço daqui"}});
//# sourceMappingURL=resource.js.map