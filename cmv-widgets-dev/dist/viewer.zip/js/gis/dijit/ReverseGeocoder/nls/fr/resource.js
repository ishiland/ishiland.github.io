/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{address:"Adresse",neighborhood:"Quartier",city:"Ville",subregion:"Sous-région",region:"Région",postalCode:"Code postal",countryCode:"Code de pays",locatorName:"Nom du localisateur",getAddressHere:"Obtenir l'adresse ici"}});
//# sourceMappingURL=resource.js.map