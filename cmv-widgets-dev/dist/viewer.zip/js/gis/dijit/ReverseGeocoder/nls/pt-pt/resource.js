/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{address:"Endereço",neighborhood:"Bairro",city:"Cidade",subregion:"Subregião",region:"Região",postalCode:"Código postal",countryCode:"Código do país",locatorName:"Nome do localizador",getAddressHere:"Obter o endereço daqui"}});
//# sourceMappingURL=resource.js.map