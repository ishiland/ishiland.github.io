/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{point:"Ponto",circle:"Círculo",polyline:"Polilinha",freehandPolyline:"Polilinha a Mão Livre",polygon:"Polígono",freehandPolygon:"Polígono a Mão Livre",stopDrawing:"Parar de Desenhar",clearDrawing:"Limpar Desenhos",currentDrawMode:"Modo de desenho atual:",currentDrawModeNone:"Nenhum"}});
//# sourceMappingURL=resource.js.map