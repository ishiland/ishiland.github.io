/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({root:{labels:{point:"Point",circle:"Circle",polyline:"Polyline",freehandPolyline:"Freehand polyline",polygon:"Polygon",freehandPolygon:"Freehand polygon",stopDrawing:"Stop drawing",clearDrawing:"Clear drawing",currentDrawMode:"Current draw mode:",currentDrawModeNone:"None"}},es:!0,fr:!0,"pt-br":!0,"pt-pt":!0});
//# sourceMappingURL=resource.js.map