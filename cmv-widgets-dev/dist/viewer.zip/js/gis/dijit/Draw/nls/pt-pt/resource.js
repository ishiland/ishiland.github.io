/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{point:"Ponto",circle:"Círculo",polyline:"Polilinha",freehandPolyline:"Polilinha à mão livre",polygon:"Polígono",freehandPolygon:"Polígono à mão livre",stopDrawing:"Parar de desenhar",clearDrawing:"Limpar desenhos",currentDrawMode:"Modo de desenho actual:",currentDrawModeNone:"Nenhum"}});
//# sourceMappingURL=resource.js.map