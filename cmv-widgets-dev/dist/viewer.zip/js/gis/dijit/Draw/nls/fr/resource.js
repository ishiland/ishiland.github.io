/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{point:"Point",circle:"Cercle",polyline:"Polyline",freehandPolyline:"Polyligne à main levée",polygon:"Polygone",freehandPolygon:"Polygone à main levée",stopDrawing:"Terminer le dessin",clearDrawing:"Effacer le dessin",currentDrawMode:"Mode de dessin:",currentDrawModeNone:"Aucun"}});
//# sourceMappingURL=resource.js.map