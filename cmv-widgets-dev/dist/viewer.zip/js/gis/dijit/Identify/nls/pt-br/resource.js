/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{selectLayer:'Escolha "Todas Camadas Visíveis" ou uma camada única para Identificar:',allVisibleLayers:"*** Todas Camadas Visíveis ***"},rightClickMenuItem:{label:"Identifique aqui"},mapInfoWindow:{identifyingTitle:"Identificando..."}});
//# sourceMappingURL=resource.js.map