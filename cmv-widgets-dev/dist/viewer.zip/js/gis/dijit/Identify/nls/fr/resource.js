/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{selectLayer:'Choisissez "Tous les calques visibles" ou une seule couche pour identifier:',allVisibleLayers:"*** Tous les calques visibles ***"},rightClickMenuItem:{label:"Identifier ici"},mapInfoWindow:{identifyingTitle:"Identification..."}});
//# sourceMappingURL=resource.js.map