/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{selectLayer:'Escolher "Todas as camadas visíveis" ou uma única camada para identificar:',allVisibleLayers:"*** Todas as camadas visíveis ***"},rightClickMenuItem:{label:"Identificar aqui"},mapInfoWindow:{identifyingTitle:"A identificar..."}});
//# sourceMappingURL=resource.js.map