/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define(["dojo/_base/declare","dijit/_WidgetBase","dijit/_TemplatedMixin","dijit/_Contained","./_Control"],function(e,i,n,t,a){return e([i,n,t,a],{_layerType:"overlay",_esriLayerType:"wms",_layerTypeInit:function(){this._expandRemove()}})});
//# sourceMappingURL=WMS.js.map