/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define(["dojo/_base/declare","dijit/_WidgetBase","dijit/_TemplatedMixin","dijit/_Contained","./_Control"],function(e,i,t,n,a){return e([i,t,n,a],{_layerType:"overlay",_esriLayerType:"vectortile",_layerTypeInit:function(){this._expandRemove()}})});
//# sourceMappingURL=VectorTile.js.map