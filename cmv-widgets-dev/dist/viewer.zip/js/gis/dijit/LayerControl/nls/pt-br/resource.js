/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({noLegend:"Sem Legenda",moveUp:"Mover para Cima",moveDown:"Mover para Baixo",zoomTo:"Zoom para a Camada",transparency:"Transparência",metadata:"Metadados",layerSwipe:"Cortina de Camada",layerSwipeVertical:"Vertical",layerSwipeHorizontal:"Horizontal",layerSwipeScope:"Escopo",dynamicSublayersOn:"Liga todas Subcamadas",dynamicSublayersOff:"Desliga todas Subcamadas"});
//# sourceMappingURL=resource.js.map