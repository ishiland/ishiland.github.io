/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({noLegend:"Aucune légende",moveUp:"Déplacer vers le haut",moveDown:"Descendre",zoomTo:"Zoom sur la couche",transparency:"Transparence",metadata:"Métadonnées",layerSwipe:"Couche swipe",layerSwipeVertical:"Vertical",layerSwipeHorizontal:"Horizontal",layerSwipeScope:"Étendue",dynamicSublayersOn:"Activer toutes les sous-couches",dynamicSublayersOff:"Éteignez toutes les sous-couches"});
//# sourceMappingURL=resource.js.map