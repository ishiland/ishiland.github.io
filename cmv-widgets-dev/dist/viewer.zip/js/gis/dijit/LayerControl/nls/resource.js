/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({root:{noLegend:"No Legend",moveUp:"Move Up",moveDown:"Move Down",zoomTo:"Zoom to Layer",transparency:"Transparency",metadata:"Metadata",layerSwipe:"Layer Swipe",layerSwipeVertical:"Vertical",layerSwipeHorizontal:"Horizontal",layerSwipeScope:"Scope",dynamicSublayersOn:"Turn On All Sublayers",dynamicSublayersOff:"Turn Off All Sublayers"},es:!0,fr:!0,"pt-br":!0,"pt-pt":!0});
//# sourceMappingURL=resource.js.map