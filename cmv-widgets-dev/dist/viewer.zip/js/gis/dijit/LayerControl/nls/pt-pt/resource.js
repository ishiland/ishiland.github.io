/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({noLegend:"Sem legenda",moveUp:"Mover para cima",moveDown:"Mover para baixo",zoomTo:"Aproximar à Camada",transparency:"Transparência",metadata:"Metadados",layerSwipe:"Deslizar camada",layerSwipeVertical:"Vertical",layerSwipeHorizontal:"Horizontal",layerSwipeScope:"Janela",dynamicSublayersOn:"Activar todas as subcamadas",dynamicSublayersOff:"Desligar todas as subcamadas"});
//# sourceMappingURL=resource.js.map