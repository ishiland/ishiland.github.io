/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{startEditing:"Commencez à éditer",stopEditing:"Arrêter l'édition"}});
//# sourceMappingURL=resource.js.map