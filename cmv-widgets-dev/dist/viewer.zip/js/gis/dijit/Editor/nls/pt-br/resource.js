/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({labels:{startEditing:"Iniciar Edição",stopEditing:"Parar Edição"}});
//# sourceMappingURL=resource.js.map