/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({root:{labels:{startEditing:"Start editing",stopEditing:"Stop editing"}},es:!0,fr:!0,"pt-br":!0,"pt-pt":!0});
//# sourceMappingURL=resource.js.map