/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({messages:{instructions:"Clique no botão do StreetView e depois clique na localização desejada no mapa.",notAvailable:"Infelizmente, o Google Street View não está disponível nesta localização."},rightClickMenuItem:{label:"Street View aqui"}});
//# sourceMappingURL=resource.js.map