/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({root:{messages:{instructions:"Click the StreetView button then click the map at your desired location.",notAvailable:"Unfortunately, Google StreetView imagery is not yet available at that location."},rightClickMenuItem:{label:"Google StreetView here"}},es:!0,fr:!0,"pt-br":!0,"pt-pt":!0});
//# sourceMappingURL=resource.js.map