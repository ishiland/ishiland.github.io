/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({messages:{instructions:"Cliquez sur le bouton StreetView puis cliquez sur la carte à l'endroit désiré.",notAvailable:"Malheureusement, les images de Google StreetView ne sont pas encore disponible à cet endroit."},rightClickMenuItem:{label:"Ouvrir Google StreetView à cet endroit"}});
//# sourceMappingURL=resource.js.map