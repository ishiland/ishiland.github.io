/*  ConfigurableMapViewerCMV
 *  version 2.0.0-beta.2
 *  Project: https://cmv.io/
 */

define({selectLocale:"Sélectionnez votre lieu :"});
//# sourceMappingURL=resource.js.map